public class Estudiante {
    //Atributos
    private String nombre;
        
    //Constructores
    public Estudiante() {
            
    }

    public Estudiante(String nombre) {
        this.nombre = nombre;
    }

    //Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }    
}